# Imgret (Image Retrieval)

A simple image retrieval application